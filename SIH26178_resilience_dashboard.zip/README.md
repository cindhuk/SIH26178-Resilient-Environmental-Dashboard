
# SIH26178 Resilient Environmental Intelligence Hub

A Streamlit-based software prototype for Team Inferno Six.

## What it demonstrates

- Multi-node environmental monitoring
- Flood and air-quality representative use cases
- Edge risk analysis using transparent demo rules
- Local alert generation
- Network failure simulation
- Store-and-forward critical alert queue
- Network recovery and alert synchronization
- Node overview/map
- Sensor and communication health
- Environmental trend visualization

## Important

This is a **software resilience simulator / digital prototype**.

The current risk engine is intentionally threshold-based for demonstration. Do not present it as a trained or validated ML model. For the final hardware implementation, replace the demo functions in `app.py` with a trained/evaluated lightweight model and deploy it on the edge device.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local Streamlit URL shown in the terminal.

## Suggested SIH demo

1. Select N-03 (Flood).
2. Increase water level/rise rate/rainfall.
3. Show HIGH risk.
4. Click **Trigger Current Node Alert**.
5. Click **Simulate Network Failure**.
6. Trigger another HIGH-risk alert.
7. Show it in **Critical Alert Queue**.
8. Click **Restore Network & Synchronize**.
9. Show the alert moving to **Synchronized Alert History**.

## Future hardware mapping

Software simulator -> planned hardware:
- Sensor inputs -> physical sensors
- Risk engine -> lightweight edge ML model
- Local alert -> buzzer/LED
- Network -> LoRa/Wi-Fi
- Queue -> local persistent storage
- Dashboard -> backend + web/mobile interface
