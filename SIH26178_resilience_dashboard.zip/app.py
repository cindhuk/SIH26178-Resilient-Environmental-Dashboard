
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import random

st.set_page_config(
    page_title="SIH26178 | Resilient Environmental Intelligence Hub",
    page_icon="🌐",
    layout="wide",
)

# -----------------------------
# Session state
# -----------------------------
if "network_online" not in st.session_state:
    st.session_state.network_online = True

if "queued_alerts" not in st.session_state:
    st.session_state.queued_alerts = []

if "synced_alerts" not in st.session_state:
    st.session_state.synced_alerts = []

if "last_event" not in st.session_state:
    st.session_state.last_event = None

if "node_readings" not in st.session_state:
    st.session_state.node_readings = {
        "N-01": {"hazard": "Flood", "lat": 11.399, "lon": 79.691, "water": 32, "rise": 1.2, "rain": 8, "pm25": 28, "pm10": 45, "temp": 30, "humidity": 72, "battery": 86},
        "N-02": {"hazard": "Air", "lat": 11.403, "lon": 79.684, "water": 18, "rise": 0.5, "rain": 4, "pm25": 48, "pm10": 72, "temp": 31, "humidity": 68, "battery": 74},
        "N-03": {"hazard": "Flood", "lat": 11.392, "lon": 79.700, "water": 78, "rise": 5.8, "rain": 35, "pm25": 55, "pm10": 88, "temp": 29, "humidity": 84, "battery": 61},
        "N-04": {"hazard": "Air", "lat": 11.410, "lon": 79.706, "water": 21, "rise": 0.7, "rain": 6, "pm25": 152, "pm10": 224, "temp": 34, "humidity": 70, "battery": 49},
        "N-05": {"hazard": "Flood", "lat": 11.386, "lon": 79.680, "water": 45, "rise": 2.2, "rain": 15, "pm25": 38, "pm10": 61, "temp": 30, "humidity": 76, "battery": 92},
        "N-06": {"hazard": "Air", "lat": 11.417, "lon": 79.693, "water": 17, "rise": 0.4, "rain": 3, "pm25": 24, "pm10": 41, "temp": 29, "humidity": 65, "battery": 81},
    }

# -----------------------------
# Prototype risk engine
# -----------------------------
def clamp(value, low=0, high=100):
    return max(low, min(high, value))

def flood_risk(water, rise, rain):
    # Demonstration threshold logic.
    # Replace with a trained/evaluated ML model for the hardware implementation.
    score = (
        (water / 100) * 45
        + (rise / 8) * 30
        + (rain / 50) * 25
    )
    score = clamp(score)

    if score >= 70:
        level = "HIGH"
    elif score >= 40:
        level = "MEDIUM"
    else:
        level = "LOW"

    reasons = []
    if water >= 70:
        reasons.append("high water level")
    if rise >= 4:
        reasons.append("rapid water-level rise")
    if rain >= 30:
        reasons.append("heavy rainfall")
    if not reasons:
        reasons.append("parameters within normal range")

    return round(score), level, reasons

def air_risk(pm25, pm10):
    score = (
        (pm25 / 200) * 65
        + (pm10 / 300) * 35
    )
    score = clamp(score)

    if score >= 70:
        level = "HIGH"
    elif score >= 40:
        level = "MEDIUM"
    else:
        level = "LOW"

    reasons = []
    if pm25 >= 100:
        reasons.append("high PM2.5")
    if pm10 >= 180:
        reasons.append("high PM10")
    if not reasons:
        reasons.append("particulate levels within demo limits")

    return round(score), level, reasons

def get_risk(node):
    if node["hazard"] == "Flood":
        return flood_risk(node["water"], node["rise"], node["rain"])
    return air_risk(node["pm25"], node["pm10"])

def add_alert(node_id, node, score, level, reasons):
    if level != "HIGH":
        return None

    now = datetime.now().strftime("%H:%M:%S")
    alert = {
        "id": f"ALT-{random.randint(100,999)}",
        "time": now,
        "node": node_id,
        "hazard": node["hazard"],
        "risk": level,
        "score": score,
        "reason": ", ".join(reasons),
        "status": "QUEUED" if not st.session_state.network_online else "SYNCED",
    }

    if st.session_state.network_online:
        st.session_state.synced_alerts.insert(0, alert)
    else:
        st.session_state.queued_alerts.insert(0, alert)

    st.session_state.last_event = alert
    return alert

# -----------------------------
# Header
# -----------------------------
st.title("🌐 Resilient Environmental Intelligence Hub")
st.caption("SIH26178 • Inferno Six • Software Resilience & Dashboard Prototype")

# Status strip
nodes = st.session_state.node_readings
risk_results = {nid: get_risk(node) for nid, node in nodes.items()}
high_count = sum(1 for r in risk_results.values() if r[1] == "HIGH")
medium_count = sum(1 for r in risk_results.values() if r[1] == "MEDIUM")

c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    st.metric("Active Nodes", f"{len(nodes)}/6")
with c2:
    st.metric("Network", "ONLINE" if st.session_state.network_online else "OFFLINE")
with c3:
    st.metric("Edge Engine", "ACTIVE")
with c4:
    st.metric("High-Risk Nodes", high_count)
with c5:
    st.metric("Queued Alerts", len(st.session_state.queued_alerts))

st.divider()

# -----------------------------
# Sidebar controls
# -----------------------------
st.sidebar.header("🎛️ Demonstration Controls")

selected_node = st.sidebar.selectbox(
    "Select sensor node",
    list(nodes.keys()),
)

node = nodes[selected_node]

st.sidebar.subheader("Simulate sensor readings")

if node["hazard"] == "Flood":
    node["water"] = st.sidebar.slider("Water level (cm)", 0, 120, int(node["water"]))
    node["rise"] = st.sidebar.slider("Rise rate (cm / 10 min)", 0.0, 10.0, float(node["rise"]), 0.1)
    node["rain"] = st.sidebar.slider("Rainfall (mm/h)", 0, 80, int(node["rain"]))
else:
    node["pm25"] = st.sidebar.slider("PM2.5 (µg/m³)", 0, 300, int(node["pm25"]))
    node["pm10"] = st.sidebar.slider("PM10 (µg/m³)", 0, 500, int(node["pm10"]))

node["temp"] = st.sidebar.slider("Temperature (°C)", 15, 50, int(node["temp"]))
node["humidity"] = st.sidebar.slider("Humidity (%)", 20, 100, int(node["humidity"]))

st.sidebar.divider()

if st.sidebar.button("🔴 Simulate Network Failure", use_container_width=True):
    st.session_state.network_online = False
    st.rerun()

if st.sidebar.button("🟢 Restore Network & Synchronize", use_container_width=True):
    st.session_state.network_online = True

    for alert in st.session_state.queued_alerts:
        alert["status"] = "SYNCED"
        st.session_state.synced_alerts.insert(0, alert)

    st.session_state.queued_alerts = []
    st.rerun()

if st.sidebar.button("🧹 Reset Demo", use_container_width=True):
    st.session_state.network_online = True
    st.session_state.queued_alerts = []
    st.session_state.synced_alerts = []
    st.session_state.last_event = None
    st.rerun()

# -----------------------------
# Network / resilience banner
# -----------------------------
if st.session_state.network_online:
    st.success("📡 NETWORK ONLINE  •  🧠 EDGE INTELLIGENCE ACTIVE  •  🔔 LOCAL DETECTION ACTIVE")
else:
    st.error("📡 NETWORK OFFLINE  •  🧠 EDGE INTELLIGENCE ACTIVE  •  🔔 LOCAL DETECTION ACTIVE  •  💾 STORE-AND-FORWARD ENABLED")

# -----------------------------
# Selected node risk analysis
# -----------------------------
score, level, reasons = get_risk(node)

st.subheader(f"🧠 Edge Risk Analysis — {selected_node}")

a, b, c, d = st.columns(4)

if node["hazard"] == "Flood":
    a.metric("Water Level", f"{node['water']} cm")
    b.metric("Rise Rate", f"{node['rise']} cm/10m")
    c.metric("Rainfall", f"{node['rain']} mm/h")
    d.metric("Risk Score", f"{score}%")
else:
    a.metric("PM2.5", f"{node['pm25']} µg/m³")
    b.metric("PM10", f"{node['pm10']} µg/m³")
    c.metric("Temperature", f"{node['temp']} °C")
    d.metric("Risk Score", f"{score}%")

if level == "HIGH":
    st.error(f"🔴 HIGH RISK — {node['hazard']}")
elif level == "MEDIUM":
    st.warning(f"🟡 MEDIUM RISK — {node['hazard']}")
else:
    st.success(f"🟢 LOW RISK — {node['hazard']}")

st.write("**Reason:** " + " + ".join(reasons))

if st.button("🚨 Trigger Current Node Alert"):
    alert = add_alert(selected_node, node, score, level, reasons)
    if alert:
        if st.session_state.network_online:
            st.success(f"{alert['id']} sent to backend and dashboard.")
        else:
            st.warning(f"{alert['id']} stored locally in the offline queue.")
    else:
        st.info("Current risk is not HIGH, so no critical alert was generated.")

# -----------------------------
# Node map / overview
# -----------------------------
st.subheader("📍 Distributed Node Overview")

map_rows = []
for nid, n in nodes.items():
    s, l, _ = get_risk(n)
    map_rows.append({
        "Node": nid,
        "Latitude": n["lat"],
        "Longitude": n["lon"],
        "Risk Score": s,
        "Risk": l,
        "Hazard": n["hazard"],
    })

map_df = pd.DataFrame(map_rows)

left, right = st.columns([1.25, 1])

with left:
    st.map(map_df[["Latitude", "Longitude"]], latitude="Latitude", longitude="Longitude", size=150)

with right:
    display_df = map_df[["Node", "Hazard", "Risk", "Risk Score"]].copy()
    st.dataframe(display_df, use_container_width=True, hide_index=True)

# -----------------------------
# Sensor health
# -----------------------------
st.subheader("🔧 Sensor & Communication Health")

health_rows = []
for nid, n in nodes.items():
    s, l, _ = get_risk(n)
    battery_status = "GOOD" if n["battery"] >= 50 else "LOW"

    health_rows.append({
        "Node": nid,
        "Water/Rain": "OK",
        "Air Sensor": "OK",
        "Battery": f"{n['battery']}%",
        "Battery Status": battery_status,
        "Communication": "CONNECTED" if st.session_state.network_online else "DISCONNECTED",
        "Edge Engine": "ACTIVE",
    })

st.dataframe(pd.DataFrame(health_rows), use_container_width=True, hide_index=True)

# -----------------------------
# Offline queue
# -----------------------------
st.subheader("📦 Critical Alert Queue — Store & Forward")

if st.session_state.queued_alerts:
    st.dataframe(
        pd.DataFrame(st.session_state.queued_alerts),
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("No unsynchronized critical alerts.")

# -----------------------------
# Synchronized alerts
# -----------------------------
st.subheader("☁️ Synchronized Alert History")

if st.session_state.synced_alerts:
    st.dataframe(
        pd.DataFrame(st.session_state.synced_alerts),
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("No synchronized alerts yet.")

# -----------------------------
# Simple trend simulation
# -----------------------------
st.subheader("📈 Environmental Trend")

selected_history = []
base = node["water"] if node["hazard"] == "Flood" else node["pm25"]

for i in range(12):
    noise = random.uniform(-0.08, 0.08) * max(base, 1)
    trend = i * (0.02 * max(base, 1))
    selected_history.append(base + trend + noise)

trend_df = pd.DataFrame({
    "Time Window": list(range(12)),
    "Reading": selected_history,
})

st.line_chart(trend_df.set_index("Time Window"))

# -----------------------------
# Architecture explanation
# -----------------------------
st.subheader("🔄 Resilience Workflow")

st.markdown("""
**Sense → Validate → Analyze Locally → Alert Locally → Communicate → Synchronize**

**Normal:** Sensor → Edge Risk Engine → Local Alert → Network → Backend/Dashboard

**Network failure:** Sensor → Edge Risk Engine → Local Alert → Local Queue

**Recovery:** Network Restored → Queued Critical Alerts → Backend/Dashboard
""")

st.info(
    "Prototype note: the current risk engine uses transparent threshold-based demonstration logic. "
    "It is not a trained/validated ML model. The final hardware implementation can replace this "
    "logic with a lightweight trained model running on the edge device."
)

st.caption("SIH26178 • Inferno Six • Resilience Simulator / Digital Prototype")
